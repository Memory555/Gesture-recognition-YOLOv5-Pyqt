from utils.autoanchor import *

config="./data/copy_voc.yaml"

_=kmean_anchors(config)